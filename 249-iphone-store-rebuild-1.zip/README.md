# 249 iPhone — phone store website

Black / orange / white storefront in Arabic (RTL) and English (LTR). Customers pick a phone and order on WhatsApp —
no account, no cart, no form. Built with Vite + React + TypeScript + Tailwind CSS.

## Run it locally
```bash
npm install
npm run dev        # open http://localhost:3000
npm run lint       # type-check
npm run build      # creates the dist/ folder
npm run preview    # test the production build locally
```

## 1. Set the WhatsApp number  (src/config/site.ts)
```ts
phone: '0121816126',        // shown on the site
whatsapp: '249121816126',   // international format, digits only, no + and no leading 0
```
These are the numbers that were already in your old project. The country code (249 = Sudan) was an assumption
by the original author, so **verify it**: tap any "Order via WhatsApp" button and check the right chat opens.
Every button, the floating button and the footer read from this one file.

## 2. Add or edit phones  (src/data/products.ts)
Copy one block, change it, save. Put the photo in `public/images/` and reference it as `images/<file>.jpg`.
- `price: { amount: 1200, currency: 'USD' }` — optional. Without it the site shows "السعر عند الطلب / Price on request".
  When products have prices, the price filter and price sorting appear automatically, and the price goes into the WhatsApp message.
- `condition: 'new' | 'used' | 'refurbished'` and `sim: ['عربي', 'English']` — optional; shown only when present.
- Filters (brand, storage, condition, price) only appear when your products actually differ in that field.
- `npm run dev` then open `/#/admin` for a form that writes the product block for you (development only — it is not in the live site).

## 3. Deploy to Netlify
- **Drag and drop:** run `npm run build`, then drag the `dist` folder onto https://app.netlify.com/drop.
- **From GitHub (recommended):** push the project, then in Netlify choose *Add new site → Import from Git*.
  `netlify.toml` already sets the build command (`npm run build`), publish folder (`dist`) and Node 22.
Each time you change products or settings, build again (or push to GitHub) to update the live site.

## Good to know
- Orders are not stored anywhere: the button opens WhatsApp with a ready message and the customer presses Send.
- Photos appear to come from GSMArena and carry its watermark. Using your own photos is safer for a live shop.
- Fonts (IBM Plex Sans Arabic, Readex Pro) load from Google Fonts.
