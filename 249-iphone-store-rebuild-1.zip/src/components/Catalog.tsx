import { useMemo, useState } from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { products } from '../data/products';
import { activeFilterCount, applyFilters, facets, hasActiveFilters, EMPTY_FILTERS, type Filters, type SortKey } from '../lib/catalog';
import { CATEGORY_LABEL, CONDITION_LABEL } from '../lib/ui-strings';
import { useI18n } from '../lib/i18n';
import { ProductCard } from './ProductCard';
import { Select } from './Select';

const numberInput = 'h-12 w-full rounded-xl border border-line bg-panel px-3 text-base font-normal text-white transition-colors hover:border-orange-500 sm:h-11 sm:text-sm';

export function Catalog({ filters, setFilters }: { filters: Filters; setFilters: (f: Filters) => void }) {
  const { t, tx } = useI18n();
  const [open, setOpen] = useState(false);
  const fx = useMemo(() => facets(products), []);
  const list = useMemo(() => applyFilters(products, filters), [filters]);
  const set = (patch: Partial<Filters>) => setFilters({ ...filters, ...patch });

  const hasPanel = fx.brands.length > 1 || fx.storages.length > 1 || fx.conditions.length > 1 || !!fx.price;
  const n = activeFilterCount(filters);
  const sorts: { key: SortKey; label: string }[] = [
    ...(fx.generations.length > 1 ? [{ key: 'newest' as SortKey, label: t('sortNewest') }] : [{ key: 'featured' as SortKey, label: t('sortNewest') }]),
    { key: 'name', label: t('sortName') },
    ...(fx.price ? [{ key: 'priceLow' as SortKey, label: t('sortPriceLow') }, { key: 'priceHigh' as SortKey, label: t('sortPriceHigh') }] : [])
  ];

  return (
    <section id="catalog" className="mx-auto max-w-7xl px-4 pb-24 pt-6 sm:px-6 lg:px-8">
      <h1 className="font-display text-xl font-semibold tracking-tight sm:text-2xl">{t('catalogTitle')}</h1>

      {fx.categories.length > 1 && (
        <div className="-mx-4 mt-4 overflow-x-auto px-4 sm:mx-0 sm:px-0" role="tablist">
          <div className="flex min-w-max gap-2">
            {['', ...fx.categories].map((c) => {
              const active = filters.category === c;
              return (
                <button key={c || 'all'} type="button" role="tab" aria-selected={active} onClick={() => set({ category: c })}
                  className={`h-11 rounded-full border px-5 text-sm font-medium transition-colors ${active ? 'border-orange-500 bg-orange-500 text-black' : 'border-line text-white hover:border-orange-500'}`}>
                  {c ? tx(CATEGORY_LABEL[c as keyof typeof CATEGORY_LABEL]) : t('all')}
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="mt-4 flex items-end gap-3">
        {hasPanel && (
          <button type="button" onClick={() => setOpen(!open)} aria-expanded={open}
            className="flex h-12 items-center gap-2 rounded-xl border border-line bg-panel px-4 text-sm font-medium text-white hover:border-orange-500 md:hidden">
            <SlidersHorizontal className="h-4 w-4" aria-hidden="true" />{t('filters')}{n > 0 ? ` (${n})` : ''}
          </button>
        )}
        <div className="ms-auto w-48 sm:w-56">
          <Select label={t('sort')} hideLabel value={filters.sort} onChange={(v) => set({ sort: v as SortKey })}>
            {sorts.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
          </Select>
        </div>
      </div>

      {hasPanel && (
        <div className={`mt-3 grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-5 ${open ? 'grid' : 'hidden md:grid'}`}>
          {fx.brands.length > 1 && (
            <Select label={t('filterBrand')} value={filters.brand} onChange={(v) => set({ brand: v })}>
              <option value="">{t('anyOption')}</option>
              {fx.brands.map((b) => <option key={b} value={b}>{b}</option>)}
            </Select>
          )}
          {fx.storages.length > 1 && (
            <Select label={t('filterStorage')} value={filters.storage} onChange={(v) => set({ storage: v })}>
              <option value="">{t('anyOption')}</option>
              {fx.storages.map((s) => <option key={s} value={s}>{s}</option>)}
            </Select>
          )}
          {fx.conditions.length > 1 && (
            <Select label={t('filterCondition')} value={filters.condition} onChange={(v) => set({ condition: v })}>
              <option value="">{t('anyOption')}</option>
              {fx.conditions.map((c) => <option key={c} value={c}>{tx(CONDITION_LABEL[c])}</option>)}
            </Select>
          )}
          {fx.price && (
            <>
              <label className="flex min-w-0 flex-col gap-1 text-xs font-medium text-mute">{t('priceMin')} ({fx.price.currency})
                <input type="number" inputMode="numeric" min={0} value={filters.minPrice} onChange={(e) => set({ minPrice: e.target.value })} className={numberInput} />
              </label>
              <label className="flex min-w-0 flex-col gap-1 text-xs font-medium text-mute">{t('priceMax')} ({fx.price.currency})
                <input type="number" inputMode="numeric" min={0} value={filters.maxPrice} onChange={(e) => set({ maxPrice: e.target.value })} className={numberInput} />
              </label>
            </>
          )}
        </div>
      )}

      <div className="mt-4 flex items-center justify-between gap-4 text-sm text-mute" aria-live="polite">
        <span>{t('results', { n: list.length })}</span>
        {hasActiveFilters(filters) && (
          <button type="button" onClick={() => setFilters(EMPTY_FILTERS)} className="font-medium text-orange-500 underline underline-offset-4 hover:text-orange-400">
            {t('clearFilters')}
          </button>
        )}
      </div>

      {list.length > 0 ? (
        <ul className="mt-4 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-4">
          {list.map((p) => <li key={p.id} className="flex"><ProductCard p={p} /></li>)}
        </ul>
      ) : (
        <div className="mt-8 rounded-2xl border border-dashed border-line bg-panel px-6 py-14 text-center">
          <p className="font-display text-lg font-semibold">{t('noResults')}</p>
          <p className="mt-1 text-mute">{t('noResultsHint')}</p>
          <button type="button" onClick={() => setFilters(EMPTY_FILTERS)} className="mt-5 h-12 rounded-xl bg-orange-500 px-6 text-sm font-semibold text-black hover:bg-orange-400">
            {t('clearFilters')}
          </button>
        </div>
      )}
    </section>
  );
}
