import { Globe, MessageCircle, Search } from 'lucide-react';
import { Logo } from './Logo';
import { useI18n } from '../lib/i18n';
import { generalMessage, waLink, whatsappReady } from '../lib/contact';

function SearchBox({ q, onSearch, className = '' }: { q: string; onSearch: (v: string) => void; className?: string }) {
  const { t } = useI18n();
  return (
    <form role="search" onSubmit={(e) => e.preventDefault()} className={`relative ${className}`}>
      <Search className="pointer-events-none absolute start-4 top-1/2 h-5 w-5 -translate-y-1/2 text-mute" aria-hidden="true" />
      <input
        type="search"
        value={q}
        onChange={(e) => onSearch(e.target.value)}
        placeholder={t('search')}
        aria-label={t('search')}
        className="h-12 w-full rounded-full border border-line bg-panel ps-12 pe-4 text-base text-white placeholder:text-mute transition-colors hover:border-orange-500 focus:border-orange-500"
      />
    </form>
  );
}

export function Header({ q, onSearch }: { q: string; onSearch: (v: string) => void }) {
  const { lang, setLang, t } = useI18n();
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-ink/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6 lg:px-8">
        <a href="#/" className="shrink-0 rounded-lg" aria-label="Home"><Logo /></a>
        <SearchBox q={q} onSearch={onSearch} className="mx-auto hidden w-full max-w-xl md:block" />
        <div className="ms-auto flex items-center gap-2 md:ms-0">
          <button type="button" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} lang={lang === 'ar' ? 'en' : 'ar'}
            className="flex h-11 items-center gap-2 rounded-full px-3 text-sm font-medium text-white transition-colors hover:bg-panel">
            <Globe className="h-4 w-4" aria-hidden="true" />{t('langSwitch')}
          </button>
          {whatsappReady && (
            <a href={waLink(generalMessage(lang))} target="_blank" rel="noopener noreferrer" aria-label={t('whatsapp')}
              className="flex h-11 items-center gap-2 rounded-full bg-orange-500 px-4 text-sm font-semibold text-black transition active:scale-95 hover:bg-orange-400">
              <MessageCircle className="h-4 w-4" aria-hidden="true" /><span className="hidden sm:inline">{t('whatsapp')}</span>
            </a>
          )}
        </div>
      </div>
      <div className="px-4 pb-3 md:hidden"><SearchBox q={q} onSearch={onSearch} /></div>
    </header>
  );
}
