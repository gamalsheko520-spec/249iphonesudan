import { MessageCircle } from 'lucide-react';
import type { Product } from '../types';
import { asset, productHref } from '../lib/route';
import { useI18n } from '../lib/i18n';
import { CONDITION_LABEL } from '../lib/ui-strings';
import { orderMessage, waLink, whatsappReady } from '../lib/contact';
import { Price } from './Price';

export const storageSummary = (p: Product): string =>
  p.storage.length === 0 ? '' : p.storage.length === 1 ? p.storage[0] : `${p.storage[0]} – ${p.storage[p.storage.length - 1]}`;

export function ProductCard({ p }: { p: Product }) {
  const { lang, t, tx } = useI18n();
  const colors = p.colors.slice(0, 3).map((c) => tx(c)).join(' · ') + (p.colors.length > 3 ? ` +${p.colors.length - 3}` : '');

  return (
    <article className="rise group flex w-full flex-col overflow-hidden rounded-2xl bg-white text-black transition duration-200 hover:-translate-y-0.5 hover:shadow-lift">
      <a href={productHref(p.id)} className="block flex-1">
        <div className="relative aspect-[10/9] border-b border-neutral-100 p-3">
          <img src={asset(p.image)} alt={p.name} width={710} height={650} loading="lazy" decoding="async" className="h-full w-full object-contain" />
          <div className="absolute start-3 top-3 flex flex-wrap gap-1.5">
            {p.badge && <span className="rounded-full bg-black px-2.5 py-1 text-xs font-medium text-orange-500">{tx(p.badge)}</span>}
            {p.condition && <span className="rounded-full bg-neutral-100 px-2.5 py-1 text-xs font-medium text-neutral-800">{tx(CONDITION_LABEL[p.condition])}</span>}
          </div>
        </div>
        <div className="px-4 pt-3">
          <p className="text-xs font-medium text-neutral-500">{p.brand}</p>
          <h3 className="font-display text-base font-semibold leading-snug">{p.name}</h3>
          <p className="mt-2 font-display">
            <Price p={p} className="text-xl font-bold text-orange-600" emptyClassName="text-base font-medium text-neutral-600" />
          </p>
          <div className="mt-2 space-y-0.5 text-sm text-neutral-600">
            {storageSummary(p) && <p dir="ltr" style={{ textAlign: 'start' }}>{storageSummary(p)}</p>}
            {p.colors.length > 0 && <p>{t('colorsCount', { n: p.colors.length })}: {colors}</p>}
            {p.sim && <p>{t('sim')}: {tx(p.sim)}</p>}
          </div>
        </div>
      </a>
      <div className="p-4 pt-3">
        {whatsappReady ? (
          <a href={waLink(orderMessage(lang, p))} target="_blank" rel="noopener noreferrer"
            className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-orange-500 text-base font-semibold text-black transition active:scale-[0.98] hover:bg-orange-400">
            <MessageCircle className="h-5 w-5" aria-hidden="true" />{t('orderWhatsApp')}
          </a>
        ) : (
          <a href={productHref(p.id)} className="flex h-12 w-full items-center justify-center rounded-xl bg-black text-base font-semibold text-white">{p.name}</a>
        )}
      </div>
    </article>
  );
}
