import { MessageCircle, Phone } from 'lucide-react';
import { LogoMark } from './Logo';
import { SITE } from '../config/site';
import { useI18n } from '../lib/i18n';
import { generalMessage, phoneReady, telLink, waLink, whatsappReady } from '../lib/contact';
import { products } from '../data/products';
import { CATEGORY_LABEL } from '../lib/ui-strings';

export function Footer({ onCategory }: { onCategory: (c: string) => void }) {
  const { lang, t, tx } = useI18n();
  const cats = [...new Set(products.map((p) => p.category))];
  return (
    <footer className="border-t border-line bg-ink text-neutral-300">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr] lg:px-8">
        <div>
          <div className="flex items-center gap-2.5"><LogoMark className="h-9 w-9" /><span className="font-display text-lg font-semibold text-white">{SITE.name[lang]}</span></div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-mute">{t('footerNote')}</p>
        </div>
        {cats.length > 1 && (
          <nav aria-label={t('footerShop')}>
            <h2 className="font-display text-base font-semibold text-white">{t('footerShop')}</h2>
            <ul className="mt-4 space-y-1 text-sm">
              {cats.map((c) => <li key={c}><a href="#/" onClick={() => onCategory(c)} className="inline-flex h-10 items-center hover:text-orange-400">{tx(CATEGORY_LABEL[c])}</a></li>)}
            </ul>
          </nav>
        )}
        {(whatsappReady || phoneReady) && (
          <div>
            <h2 className="font-display text-base font-semibold text-white">{t('footerContact')}</h2>
            <ul className="mt-4 space-y-1 text-sm">
              {whatsappReady && <li><a href={waLink(generalMessage(lang))} target="_blank" rel="noopener noreferrer" className="inline-flex h-10 items-center gap-2 hover:text-orange-400"><MessageCircle className="h-4 w-4" aria-hidden="true" />{t('whatsapp')}</a></li>}
              {phoneReady && <li><a href={telLink()} className="inline-flex h-10 items-center gap-2 hover:text-orange-400"><Phone className="h-4 w-4" aria-hidden="true" /><span dir="ltr">{SITE.phone}</span></a></li>}
            </ul>
          </div>
        )}
      </div>
      <div className="border-t border-line py-5 text-center text-xs text-mute">© {new Date().getFullYear()} {SITE.name[lang]}</div>
    </footer>
  );
}
