import { useEffect, useState, type ReactNode } from 'react';
import { products } from '../data/products';
import { useI18n } from '../lib/i18n';
import type { Category, Condition, Product, RawProduct } from '../types';

/**
 * Development-only product editor. It is NOT part of the production build, so there is
 * no password and nothing to protect: run `npm run dev`, open http://localhost:3000/#/admin,
 * fill the form, copy the result into src/data/products.ts.
 */
const pairs = (lines: string) =>
  lines.split('\n').map((l) => l.split('|').map((x) => x.trim())).filter((a) => a[0])
    .map((a) => [a[0], a[1] || a[0]] as [string, string]);

const toForm = (p?: Product) => ({
  name: p?.name ?? '', brand: p?.brand ?? 'Apple', category: (p?.category ?? 'iPhone') as Category,
  image: p?.image ?? 'images/', generation: p?.generation?.toString() ?? '',
  badge: p?.badge ? `${p.badge.ar} | ${p.badge.en}` : '',
  description: p ? `${p.description.ar} | ${p.description.en}` : '',
  colors: (p?.colors ?? []).map((c) => `${c.ar} | ${c.en}`).join('\n'),
  storage: (p?.storage ?? []).join(', '),
  specs: (p?.specs ?? []).map((c) => `${c.ar} | ${c.en}`).join('\n'),
  amount: p?.price?.amount.toString() ?? '', currency: p?.price?.currency ?? '',
  condition: (p?.condition ?? '') as Condition | ''
});

export default function Admin() {
  const { t } = useI18n();
  const [pick, setPick] = useState('');
  const [f, setF] = useState(() => toForm());
  const [copied, setCopied] = useState(false);
  useEffect(() => { setF(toForm(products.find((p) => p.id === pick))); }, [pick]);

  const set = (k: keyof typeof f, v: string) => setF((cur) => ({ ...cur, [k]: v }));
  const id = pick || f.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const desc = pairs(f.description.replace(/\n/g, ' '))[0];

  const raw: RawProduct = {
    id, name: f.name, brand: f.brand, category: f.category, image: f.image,
    ...(f.generation ? { generation: Number(f.generation) } : {}),
    ...(pairs(f.badge)[0] ? { badge: pairs(f.badge)[0] } : {}),
    description: desc ?? ['', ''],
    ...(f.colors.trim() ? { colors: pairs(f.colors) } : {}),
    ...(f.storage.trim() ? { storage: f.storage.split(',').map((s) => s.trim()).filter(Boolean) } : {}),
    ...(f.specs.trim() ? { specs: pairs(f.specs) } : {}),
    ...(f.amount && f.currency ? { price: { amount: Number(f.amount), currency: f.currency.trim() } } : {}),
    ...(f.condition ? { condition: f.condition } : {})
  };
  const out = JSON.stringify(raw, null, 2);

  const field = 'w-full rounded-xl border border-neutral-300 bg-white px-3 py-2 text-sm';
  const Lbl = ({ label, children }: { label: string; children: ReactNode }) => (
    <label className="block text-xs font-medium text-neutral-600">{label}<div className="mt-1">{children}</div></label>
  );

  return (
    <div className="mx-auto my-6 max-w-5xl rounded-2xl bg-white px-4 py-10 text-neutral-900">
      <h1 className="font-display text-2xl font-semibold">{t('adminTitle')}</h1>
      <p className="mt-2 max-w-2xl text-sm text-neutral-600">
        Fill the form, then paste the result into the RAW list in src/data/products.ts (replace the existing block when editing).
        Texts are written as “Arabic | English”, one per line. Leave price and condition empty if unknown.
      </p>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="space-y-3">
          <Lbl label="Edit existing (or leave empty for a new product)">
            <select className={field} value={pick} onChange={(e) => setPick(e.target.value)}>
              <option value="">— new product —</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </Lbl>
          <Lbl label="Name"><input className={field} value={f.name} onChange={(e) => set('name', e.target.value)} /></Lbl>
          <div className="grid grid-cols-2 gap-3">
            <Lbl label="Brand"><input className={field} value={f.brand} onChange={(e) => set('brand', e.target.value)} /></Lbl>
            <Lbl label="Category">
              <select className={field} value={f.category} onChange={(e) => set('category', e.target.value)}>
                {['iPhone', 'Apple Watch', 'AirPods', 'iPad', 'Accessories'].map((c) => <option key={c}>{c}</option>)}
              </select>
            </Lbl>
          </div>
          <Lbl label="Image path (inside /public)"><input className={field} value={f.image} onChange={(e) => set('image', e.target.value)} /></Lbl>
          <div className="grid grid-cols-2 gap-3">
            <Lbl label="iPhone generation (optional)"><input className={field} value={f.generation} onChange={(e) => set('generation', e.target.value)} /></Lbl>
            <Lbl label="Badge: Arabic | English"><input className={field} value={f.badge} onChange={(e) => set('badge', e.target.value)} /></Lbl>
          </div>
          <Lbl label="Description: Arabic | English"><textarea rows={3} className={field} value={f.description} onChange={(e) => set('description', e.target.value)} /></Lbl>
          <Lbl label="Colors (one per line: Arabic | English)"><textarea rows={3} className={field} value={f.colors} onChange={(e) => set('colors', e.target.value)} /></Lbl>
          <Lbl label="Storage / sizes (comma separated)"><input className={field} value={f.storage} onChange={(e) => set('storage', e.target.value)} /></Lbl>
          <Lbl label="Specs (one per line: Arabic | English)"><textarea rows={3} className={field} value={f.specs} onChange={(e) => set('specs', e.target.value)} /></Lbl>
          <div className="grid grid-cols-3 gap-3">
            <Lbl label="Price (optional)"><input className={field} inputMode="numeric" value={f.amount} onChange={(e) => set('amount', e.target.value)} /></Lbl>
            <Lbl label="Currency (e.g. USD)"><input className={field} value={f.currency} onChange={(e) => set('currency', e.target.value)} /></Lbl>
            <Lbl label="Condition (optional)">
              <select className={field} value={f.condition} onChange={(e) => set('condition', e.target.value)}>
                <option value="">—</option><option value="new">new</option><option value="used">used</option><option value="refurbished">refurbished</option>
              </select>
            </Lbl>
          </div>
        </div>
        <div>
          <p className="text-xs font-medium text-neutral-600">Result for src/data/products.ts</p>
          <pre dir="ltr" className="mt-1 max-h-[560px] overflow-auto rounded-xl bg-black p-4 text-xs leading-relaxed text-white">{out},</pre>
          <button type="button" className="mt-3 h-11 rounded-xl bg-orange-500 text-black px-5 text-sm font-medium hover:bg-orange-400"
            onClick={async () => { try { await navigator.clipboard.writeText(out + ','); setCopied(true); window.setTimeout(() => setCopied(false), 1500); } catch { /* clipboard blocked */ } }}>
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>
    </div>
  );
}
