import { useState } from 'react';
import { ArrowLeft, MessageCircle, Phone } from 'lucide-react';
import { products } from '../data/products';
import { asset } from '../lib/route';
import { useI18n } from '../lib/i18n';
import { isCapacity } from '../lib/catalog';
import { CATEGORY_LABEL, CONDITION_LABEL } from '../lib/ui-strings';
import { orderMessage, phoneReady, telLink, waLink, whatsappReady } from '../lib/contact';
import { SITE } from '../config/site';
import { Price } from './Price';

export function ProductPage({ id }: { id: string }) {
  const { lang, t, tx } = useI18n();
  const p = products.find((x) => x.id === id);
  // Selections are stored as positions, so switching language keeps them.
  const [colorIdx, setColorIdx] = useState(0);
  const [storageIdx, setStorageIdx] = useState(0);

  const back = (
    <a href="#/" className="inline-flex h-11 items-center gap-2 text-sm font-medium text-mute hover:text-white">
      <ArrowLeft className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />{t('back')}
    </a>
  );

  if (!p) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-semibold">{t('notFound')}</h1>
        <div className="mt-6 flex justify-center">{back}</div>
      </div>
    );
  }

  const color = p.colors[colorIdx];
  const storage = p.storage[storageIdx];
  const sizeLabel = p.storage.every(isCapacity) ? t('storage') : t('size');
  const link = whatsappReady ? waLink(orderMessage(lang, p, color, storage)) : '';
  const chip = (active: boolean) =>
    `h-11 rounded-full border px-4 text-sm font-medium transition-colors ${active ? 'border-orange-500 bg-orange-500 text-black' : 'border-line text-white hover:border-orange-500'}`;
  const orderBtn = 'flex h-14 items-center justify-center gap-2 rounded-xl bg-orange-500 px-6 text-base font-semibold text-black transition active:scale-[0.98] hover:bg-orange-400';

  return (
    <div className="mx-auto max-w-7xl px-4 pb-32 pt-4 sm:px-6 md:pb-12 lg:px-8">
      {back}
      <div className="mt-3 grid gap-8 lg:grid-cols-2 lg:gap-14">
        <div className="rise rounded-3xl bg-white p-4 sm:p-8">
          <img src={asset(p.image)} alt={p.name} width={710} height={650} decoding="async" className="mx-auto h-auto max-h-[560px] w-full object-contain" />
        </div>
        <div>
          <div className="flex flex-wrap items-center gap-2 text-sm text-mute">
            <span>{p.brand}</span><span aria-hidden="true">/</span><span>{tx(CATEGORY_LABEL[p.category])}</span>
            {p.badge && <span className="rounded-full bg-orange-500 px-2.5 py-0.5 text-xs font-semibold text-black">{tx(p.badge)}</span>}
            {p.condition && <span className="rounded-full border border-line px-2.5 py-0.5 text-xs font-medium text-white">{tx(CONDITION_LABEL[p.condition])}</span>}
          </div>
          <h1 className="mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl">{p.name}</h1>
          <p className="mt-3 font-display">
            <Price p={p} className="text-3xl font-bold text-orange-500" emptyClassName="text-xl font-medium text-mute" />
          </p>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-neutral-300">{tx(p.description)}</p>

          <div className="mt-8">
            <p className="text-sm font-medium">{t('color')}{color ? <>: <span className="font-normal text-mute">{tx(color)}</span></> : ''}</p>
            {p.colors.length > 0 ? (
              <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label={t('color')}>
                {p.colors.map((c, i) => <button key={c.en} type="button" aria-pressed={i === colorIdx} onClick={() => setColorIdx(i)} className={chip(i === colorIdx)}>{tx(c)}</button>)}
              </div>
            ) : <p className="mt-2 text-sm text-mute">{t('colorsMissing')}</p>}
          </div>

          {p.storage.length > 0 && (
            <div className="mt-6">
              <p className="text-sm font-medium">{sizeLabel}</p>
              <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label={sizeLabel} dir="ltr">
                {p.storage.map((s, i) => <button key={s} type="button" aria-pressed={i === storageIdx} onClick={() => setStorageIdx(i)} className={chip(i === storageIdx)}>{s}</button>)}
              </div>
            </div>
          )}

          <div className="mt-8 hidden md:block">
            {link ? (
              <a href={link} target="_blank" rel="noopener noreferrer" className={`${orderBtn} w-full sm:w-auto`}>
                <MessageCircle className="h-5 w-5" aria-hidden="true" />{t('orderWhatsApp')}
              </a>
            ) : <p className="text-sm text-mute">{t('contactUnavailable')}</p>}
            <p className="mt-3 text-sm text-mute">{t('orderHint')}</p>
            {phoneReady && (
              <a href={telLink()} className="mt-3 inline-flex h-11 items-center gap-2 text-sm font-medium text-white hover:text-orange-400">
                <Phone className="h-4 w-4" aria-hidden="true" /><span dir="ltr">{SITE.phone}</span>
              </a>
            )}
          </div>

          {(p.specs.length > 0 || p.sim) && (
            <div className="mt-10 border-t border-line pt-6">
              <h2 className="font-display text-lg font-semibold">{t('specs')}</h2>
              <ul className="mt-3 space-y-2 text-neutral-300">
                {p.sim && <li className="flex gap-3"><span className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-orange-500" aria-hidden="true" />{t('sim')}: {tx(p.sim)}</li>}
                {p.specs.map((s) => <li key={s.en} className="flex gap-3"><span className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-orange-500" aria-hidden="true" />{tx(s)}</li>)}
              </ul>
            </div>
          )}
        </div>
      </div>

      {link && (
        <div className="fixed inset-x-0 bottom-0 z-30 flex items-center gap-3 border-t border-line bg-ink/95 px-4 pt-3 backdrop-blur md:hidden"
          style={{ paddingBottom: 'calc(0.75rem + env(safe-area-inset-bottom, 0px))' }}>
          <div className="min-w-0 shrink-0">
            <Price p={p} className="font-display text-lg font-bold text-orange-500" emptyClassName="text-sm text-mute" />
          </div>
          <a href={link} target="_blank" rel="noopener noreferrer" className={`${orderBtn} h-12 flex-1`}>
            <MessageCircle className="h-5 w-5" aria-hidden="true" />{t('orderWhatsApp')}
          </a>
        </div>
      )}
    </div>
  );
}
