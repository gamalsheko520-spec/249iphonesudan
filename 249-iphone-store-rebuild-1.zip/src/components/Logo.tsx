import { SITE } from '../config/site';
import { useI18n } from '../lib/i18n';

/** The original four-bubble mark, redrawn for the black / orange / white identity. */
export function LogoMark({ className = 'h-9 w-9' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={className} fill="none" aria-hidden="true">
      <circle cx="34" cy="32" r="18" fill="#F58220" />
      <circle cx="68" cy="22" r="7" stroke="#F58220" strokeWidth="4" />
      <circle cx="66" cy="48" r="20" fill="#FFFFFF" />
      <circle cx="32" cy="70" r="19" fill="#F58220" />
      <circle cx="68" cy="78" r="6" fill="#FFFFFF" />
    </svg>
  );
}

export function Logo() {
  const { lang } = useI18n();
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark />
      <span className="font-display text-lg font-semibold tracking-tight text-white">{SITE.name[lang]}</span>
    </span>
  );
}
