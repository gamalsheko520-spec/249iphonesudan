import type { ReactNode } from 'react';
import { ChevronDown } from 'lucide-react';

export function Select({ label, value, onChange, children, hideLabel = false }: {
  label: string; value: string; onChange: (v: string) => void; children: ReactNode; hideLabel?: boolean;
}) {
  return (
    <label className="flex min-w-0 flex-col gap-1 text-xs font-medium text-mute">
      <span className={hideLabel ? 'sr-only' : ''}>{label}</span>
      <span className="relative block">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-12 w-full appearance-none rounded-xl border border-line bg-panel ps-3 pe-9 text-base font-normal text-white transition-colors hover:border-orange-500 sm:h-11 sm:text-sm"
        >
          {children}
        </select>
        <ChevronDown className="pointer-events-none absolute end-3 top-1/2 h-4 w-4 -translate-y-1/2 text-mute" aria-hidden="true" />
      </span>
    </label>
  );
}
