import type { Product } from '../types';
import { useI18n } from '../lib/i18n';
import { formatPrice } from '../lib/format';

/** Shows the price, or "Price on request" when the product has none. Never shows 0. */
export function Price({ p, className = '', emptyClassName = '' }: { p: Product; className?: string; emptyClassName?: string }) {
  const { lang, t } = useI18n();
  if (!p.price) return <span className={emptyClassName}>{t('priceOnRequest')}</span>;
  return <span className={className}>{formatPrice(lang, p.price)}</span>;
}
