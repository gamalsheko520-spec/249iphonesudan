import { MessageCircle } from 'lucide-react';
import { useI18n } from '../lib/i18n';
import { generalMessage, waLink, whatsappReady } from '../lib/contact';

export function FloatingWhatsApp() {
  const { lang, t } = useI18n();
  if (!whatsappReady) return null;
  return (
    <a href={waLink(generalMessage(lang))} target="_blank" rel="noopener noreferrer" aria-label={t('whatsapp')}
      className="fixed end-4 z-30 grid h-14 w-14 place-items-center rounded-full bg-orange-500 text-black shadow-lift transition active:scale-95 hover:bg-orange-400"
      style={{ bottom: 'calc(1rem + env(safe-area-inset-bottom, 0px))' }}>
      <MessageCircle className="h-6 w-6" aria-hidden="true" />
    </a>
  );
}
