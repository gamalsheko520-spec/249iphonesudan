import { SITE } from '../config/site';
import type { L10n, Lang, Product } from '../types';
import { formatPrice } from './format';

const digits = (s: string) => s.replace(/\D/g, '');

export const whatsappReady = digits(SITE.whatsapp).length >= 8;
export const phoneReady = SITE.phone.trim().length > 0;

export const waLink = (text: string) =>
  `https://wa.me/${digits(SITE.whatsapp)}?text=${encodeURIComponent(text)}`;
export const telLink = () => `tel:${SITE.phone.replace(/[^\d+]/g, '')}`;

/** Prepared WhatsApp message for one product, in the visitor's current language. */
export function orderMessage(lang: Lang, p: Product, color?: L10n, storage?: string): string {
  const price = p.price ? formatPrice(lang, p.price) : '';
  if (lang === 'ar') {
    return `مرحباً! أرغب في طلب ${p.name}${storage ? `، سعة ${storage}` : ''}${color ? `، باللون ${color.ar}` : ''}. ` +
      (price ? `السعر المعلن: ${price}. ` : 'ما هو السعر؟ ') + 'هل هو متوفر؟';
  }
  return `Hello! I am interested in ordering the ${p.name}${storage ? `, ${storage}` : ''}${color ? `, in ${color.en}` : ''}. ` +
    (price ? `Listed price: ${price}. ` : 'Could you tell me the price? ') + 'Is it available?';
}

export const generalMessage = (lang: Lang) =>
  lang === 'ar' ? 'مرحباً! أود الاستفسار عن الهواتف المتوفرة.' : 'Hello! I would like to ask about your available phones.';
