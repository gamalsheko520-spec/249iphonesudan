import type { Lang, Price } from '../types';

export function formatPrice(lang: Lang, price: Price): string {
  try {
    return new Intl.NumberFormat(lang === 'ar' ? 'ar' : 'en', {
      style: 'currency', currency: price.currency, maximumFractionDigits: 0
    }).format(price.amount);
  } catch {
    return `${price.amount} ${price.currency}`; // unknown currency code
  }
}
