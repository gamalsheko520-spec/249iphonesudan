import type { Product } from '../types';
import { CATEGORY_LABEL } from './ui-strings';

export type SortKey = 'featured' | 'newest' | 'name' | 'priceLow' | 'priceHigh';

export interface Filters {
  q: string; category: string; brand: string; storage: string;
  condition: string; minPrice: string; maxPrice: string; sort: SortKey;
}

export const EMPTY_FILTERS: Filters = {
  q: '', category: '', brand: '', storage: '', condition: '', minPrice: '', maxPrice: '', sort: 'newest'
};

/** Lower-case and fold Arabic letter variants so أ / ا / إ and diacritics all match. */
export const norm = (s: string) =>
  s.toLowerCase().normalize('NFKD')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/\s+/g, ' ').trim();

const capacityGB = (s: string) => {
  const m = s.match(/([\d.]+)\s*(TB|GB)/i);
  return m ? parseFloat(m[1]) * (m[2].toUpperCase() === 'TB' ? 1024 : 1) : 0;
};
export const isCapacity = (s: string) => /\d\s*(TB|GB)$/i.test(s);

function haystack(p: Product): string {
  const cat = CATEGORY_LABEL[p.category];
  return norm([
    p.name, p.brand, p.category, cat.ar, cat.en, p.description.ar, p.description.en,
    p.badge?.ar, p.badge?.en, ...p.storage,
    ...p.colors.flatMap((c) => [c.ar, c.en]), ...p.specs.flatMap((c) => [c.ar, c.en])
  ].filter(Boolean).join(' '));
}

const uniq = <T,>(a: T[]) => [...new Set(a)];

/** Which filter options actually exist in the data. A filter is only shown when it has 2+ choices. */
export function facets(list: Product[]) {
  const priced = list.filter((p) => p.price);
  const currencies = uniq(priced.map((p) => p.price!.currency));
  return {
    categories: uniq(list.map((p) => p.category)),
    brands: uniq(list.map((p) => p.brand)).sort(),
    storages: uniq(list.flatMap((p) => p.storage).filter(isCapacity)).sort((a, b) => capacityGB(a) - capacityGB(b)),
    conditions: uniq(list.map((p) => p.condition).filter((c): c is NonNullable<typeof c> => !!c)),
    generations: uniq(list.map((p) => p.generation).filter((g): g is number => g != null)).sort((a, b) => b - a),
    price: priced.length >= 2 && currencies.length === 1
      ? { currency: currencies[0], max: Math.max(...priced.map((p) => p.price!.amount)) }
      : null
  };
}

export type Facets = ReturnType<typeof facets>;

export function applyFilters(list: Product[], f: Filters): Product[] {
  const tokens = norm(f.q).split(' ').filter(Boolean);
  const max = parseFloat(f.maxPrice);
  const min = parseFloat(f.minPrice);
  const out = list.filter((p) => {
    if (f.category && p.category !== f.category) return false;
    if (f.brand && p.brand !== f.brand) return false;
    if (f.storage && !p.storage.includes(f.storage)) return false;
    if (f.condition && p.condition !== f.condition) return false;
    if (!isNaN(max) && (!p.price || p.price.amount > max)) return false;
    if (!isNaN(min) && (!p.price || p.price.amount < min)) return false;
    if (tokens.length) { const h = haystack(p); if (!tokens.every((t) => h.includes(t))) return false; }
    return true;
  });
  const order = new Map(list.map((p, i) => [p.id, i]));
  const idx = (p: Product) => order.get(p.id) ?? 0;
  const by: Record<SortKey, (a: Product, b: Product) => number> = {
    featured: (a, b) => idx(a) - idx(b),
    newest: (a, b) => (b.generation ?? -1) - (a.generation ?? -1) || idx(a) - idx(b),
    name: (a, b) => a.name.localeCompare(b.name, 'en', { numeric: true }),
    priceLow: (a, b) => (a.price?.amount ?? Infinity) - (b.price?.amount ?? Infinity) || idx(a) - idx(b),
    priceHigh: (a, b) => (b.price?.amount ?? -Infinity) - (a.price?.amount ?? -Infinity) || idx(a) - idx(b)
  };
  // While searching, devices whose NAME matches come first (so "17 pro" lists iPhone 17 Pro
  // before a phone that merely mentions an "A17 Pro" chip). Within each group the chosen sort applies.
  const nameHit = (p: Product) => (tokens.length && f.sort === 'newest' && tokens.every((t) => norm(p.name).includes(t)) ? 0 : 1);
  return out.sort((a, b) => nameHit(a) - nameHit(b) || by[f.sort](a, b));
}

export const activeFilterCount = (f: Filters) =>
  [f.category, f.brand, f.storage, f.condition, f.minPrice, f.maxPrice].filter(Boolean).length;

export const hasActiveFilters = (f: Filters) =>
  !!(f.q || f.category || f.brand || f.storage || f.condition || f.minPrice || f.maxPrice);
