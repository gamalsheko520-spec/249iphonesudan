import type { Category, Condition, L10n } from '../types';

const s = (ar: string, en: string): L10n => ({ ar, en });

export const UI = {
  tagline: s('هواتف آيفون وأجهزة آبل', 'iPhone and Apple devices'),
  skip: s('انتقل إلى المحتوى', 'Skip to content'),
  search: s('ابحث عن هاتف أو موديل', 'Search phones or models'),
  langSwitch: s('English', 'العربية'),
  catalogTitle: s('اختر هاتفك واطلبه عبر واتساب', 'Pick your phone and order on WhatsApp'),
  all: s('الكل', 'All'),
  filters: s('تصفية', 'Filters'),
  filterBrand: s('الماركة', 'Brand'),
  filterStorage: s('السعة', 'Storage'),
  filterCondition: s('الحالة', 'Condition'),
  priceMin: s('السعر من', 'Price from'),
  priceMax: s('السعر إلى', 'Price to'),
  anyOption: s('الكل', 'Any'),
  sort: s('الترتيب', 'Sort by'),
  sortNewest: s('الأحدث أولاً', 'Newest first'),
  sortName: s('الاسم', 'Name'),
  sortPriceLow: s('السعر: الأقل أولاً', 'Price: low to high'),
  sortPriceHigh: s('السعر: الأعلى أولاً', 'Price: high to low'),
  clearFilters: s('مسح التصفية', 'Clear filters'),
  results: s('{n} جهاز', '{n} devices'),
  noResults: s('لا توجد أجهزة مطابقة', 'No matching devices'),
  noResultsHint: s('جرّب كلمة بحث أخرى أو امسح التصفية.', 'Try another search or clear the filters.'),
  priceOnRequest: s('السعر عند الطلب', 'Price on request'),
  orderWhatsApp: s('اطلب عبر واتساب', 'Order via WhatsApp'),
  orderHint: s('يفتح واتساب برسالة جاهزة، وتضغط أنت «إرسال».', 'Opens WhatsApp with a ready message — you press Send.'),
  whatsapp: s('واتساب', 'WhatsApp'),
  call: s('اتصال', 'Call'),
  back: s('العودة إلى الأجهزة', 'Back to devices'),
  color: s('اللون', 'Color'),
  colorsCount: s('{n} ألوان', '{n} colors'),
  colorsMissing: s('الألوان غير محددة — اسألنا عبر واتساب', 'Colors not listed — ask us on WhatsApp'),
  storage: s('السعة', 'Storage'),
  size: s('المقاس', 'Size'),
  specs: s('المواصفات', 'Specifications'),
  sim: s('الشريحة', 'SIM'),
  condition: s('الحالة', 'Condition'),
  notFound: s('الجهاز غير موجود', 'Device not found'),
  contactUnavailable: s('وسائل التواصل لم تُضبط بعد.', 'Contact details have not been set up yet.'),
  footerContact: s('تواصل معنا', 'Contact'),
  footerShop: s('الأقسام', 'Shop'),
  footerNote: s('الأسعار والتوفر يؤكدها المتجر عند التواصل.', 'Prices and availability are confirmed by the store when you get in touch.'),
  adminTitle: s('محرر المنتجات (للتطوير فقط)', 'Product editor (development only)')
} satisfies Record<string, L10n>;

export type UIKey = keyof typeof UI;

export const CATEGORY_LABEL: Record<Category, L10n> = {
  iPhone: s('آيفون', 'iPhone'),
  'Apple Watch': s('ساعة آبل', 'Apple Watch'),
  AirPods: s('سماعات AirPods', 'AirPods'),
  iPad: s('آيباد', 'iPad'),
  Accessories: s('ملحقات', 'Accessories')
};

export const CONDITION_LABEL: Record<Condition, L10n> = {
  new: s('جديد', 'New'),
  used: s('مستعمل', 'Used'),
  refurbished: s('مجدَّد', 'Refurbished')
};
