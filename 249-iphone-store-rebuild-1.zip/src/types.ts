export type Lang = 'ar' | 'en';
export interface L10n { ar: string; en: string }
/** [Arabic, English] — the compact form used in src/data/products.ts */
export type Pair = [ar: string, en: string];

export type Category = 'iPhone' | 'Apple Watch' | 'AirPods' | 'iPad' | 'Accessories';
export type Condition = 'new' | 'used' | 'refurbished';
export interface Price { amount: number; currency: string }

/** Shape you edit in src/data/products.ts */
export interface RawProduct {
  id: string;
  name: string;
  brand: string;
  category: Category;
  image: string;               // path inside /public, e.g. 'images/apple-iphone-15-1.jpg'
  generation?: number;         // iPhone generation, used for "newest first" and the hero shortcuts
  badge?: Pair;
  description: Pair;
  colors?: Pair[];
  storage?: string[];          // capacities ('256GB') or sizes ('49mm')
  specs?: Pair[];
  price?: Price;               // optional — omit to show "Price on request"
  condition?: Condition;       // optional — omit if you don't track it
  sim?: Pair;                  // optional — e.g. ['شريحة واحدة', 'Single SIM']; shown only when present
}

/** Shape the UI uses (built from RawProduct) */
export interface Product {
  id: string;
  name: string;
  brand: string;
  category: Category;
  image: string;
  generation?: number;
  badge?: L10n;
  description: L10n;
  colors: L10n[];
  storage: string[];
  specs: L10n[];
  price?: Price;
  condition?: Condition;
  sim?: L10n;
}
