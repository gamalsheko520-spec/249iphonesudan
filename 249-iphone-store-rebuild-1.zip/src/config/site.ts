/**
 * STORE SETTINGS — the one place to change contact details.
 *
 * whatsapp: international format, digits only (no "+", no spaces, no leading 0).
 * phone:    how the number should look on the website.
 *
 * ⚠️ VERIFY BEFORE LAUNCH: these are the values that were already in the old
 * project. The country code 249 (Sudan) was an assumption made by its original
 * author ("0121816126" -> "249121816126"). If the code is wrong, WhatsApp will
 * open the wrong chat. Test it by tapping any "Order via WhatsApp" button.
 */
export const SITE = {
  name: { ar: '249 iPhone', en: '249 iPhone' },
  phone: '0121816126',
  whatsapp: '249121816126'
};
