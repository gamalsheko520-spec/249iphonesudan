import { Suspense, lazy, useEffect, useState } from 'react';
import { Header } from './components/Header';
import { Catalog } from './components/Catalog';
import { ProductPage } from './components/ProductPage';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { EMPTY_FILTERS, type Filters } from './lib/catalog';
import { useRoute } from './lib/route';
import { useI18n } from './lib/i18n';

// The product editor only exists in dev builds; production bundles never include it.
const Admin = import.meta.env.DEV ? lazy(() => import('./components/Admin')) : null;

export default function App() {
  const path = useRoute();
  const { t } = useI18n();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);

  const productId = path.match(/^\/product\/(.+)$/)?.[1];
  const onHome = !productId && path !== '/admin';

  useEffect(() => { window.scrollTo(0, 0); }, [path]);

  const search = (q: string) => {
    setFilters((f) => ({ ...f, q }));
    if (!onHome) window.location.hash = '#/';
  };
  const pickCategory = (c: string) => {
    setFilters({ ...EMPTY_FILTERS, category: c });
    window.setTimeout(() => window.scrollTo({ top: 0, behavior: 'smooth' }), 50);
  };

  return (
    <>
      <a href="#main" onClick={(e) => { e.preventDefault(); document.getElementById('main')?.focus(); }}
        className="sr-only focus:not-sr-only focus:fixed focus:start-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-black">{t('skip')}</a>
      <Header q={filters.q} onSearch={search} />
      <main id="main" tabIndex={-1} className="outline-none">
        {productId ? (
          <ProductPage key={productId} id={productId} />
        ) : path === '/admin' && Admin ? (
          <Suspense fallback={null}><Admin /></Suspense>
        ) : (
          <Catalog filters={filters} setFilters={setFilters} />
        )}
      </main>
      <Footer onCategory={pickCategory} />
      {!productId && <FloatingWhatsApp />}
    </>
  );
}
