/**
 * ALL PRODUCT DATA LIVES HERE.
 *
 * To add a phone: copy one block inside RAW, change the values, save.
 * Each Arabic/English text is a pair:  ['العربية', 'English'].
 *
 *  - price      optional. Leave it out and the site shows "Price on request".
 *               Use { amount: 1200, currency: 'USD' } — currency is never assumed.
 *  - condition  optional ('new' | 'used' | 'refurbished'). Leave it out if you don't track it.
 *  - sim        optional, e.g. sim: ['شريحة واحدة', 'Single SIM']. Shown only when present.
 *  - Filters (brand, condition, price, ...) appear on the site only when
 *    your products actually differ in that field.
 *
 * Photos go in /public/images and are referenced as 'images/<file>'.
 * Stock counts from the old site were NOT carried over: they were never confirmed.
 */
import type { L10n, Pair, Product, RawProduct } from '../types';

const RAW: RawProduct[] = [
  {
    id: 'iphone-15', name: 'iPhone 15', brand: 'Apple', category: 'iPhone', generation: 15,
    image: 'images/apple-iphone-15-1.jpg',
    badge: ['الأكثر طلباً', 'Most requested'],
    description: ['شريحة A16 Bionic القوية، كاميرا رئيسية 48 ميجابكسل، ومنفذ USB-C. توازن مثالي بين الأداء والسعر.',
      'Powerful A16 Bionic chip, 48MP main camera and USB-C. A balanced pick for performance and value.'],
    colors: [['وردي', 'Pink'], ['أزرق', 'Blue'], ['أصفر', 'Yellow'], ['أخضر', 'Green'], ['أسود', 'Black']],
    storage: ['128GB', '256GB', '512GB'],
    specs: [['شاشة 6.1 إنش Super Retina XDR', '6.1" Super Retina XDR display'], ['شريحة A16 Bionic', 'A16 Bionic chip'], ['منفذ USB-C', 'USB-C port']],
  },
  {
    id: 'iphone-15-pro', name: 'iPhone 15 Pro', brand: 'Apple', category: 'iPhone', generation: 15,
    image: 'images/apple-iphone-15-pro-1.jpg',
    badge: ['Pro', 'Pro'],
    description: ['هيكل تيتانيوم فاخر، شريحة A17 Pro، وزر الإجراء القابل للتخصيص لتجربة احترافية.',
      'Premium titanium build, A17 Pro chip and a customizable Action button for a pro-level experience.'],
    colors: [['تيتانيوم طبيعي', 'Natural titanium'], ['تيتانيوم أزرق', 'Blue titanium'], ['تيتانيوم أبيض', 'White titanium'], ['تيتانيوم أسود', 'Black titanium']],
    storage: ['128GB', '256GB', '512GB', '1TB'],
    specs: [['هيكل تيتانيوم درجة الطيران', 'Aerospace-grade titanium body'], ['شريحة A17 Pro', 'A17 Pro chip'], ['زر الإجراء', 'Action button']],
  },
  {
    id: 'iphone-15-pro-max', name: 'iPhone 15 Pro Max', brand: 'Apple', category: 'iPhone', generation: 15,
    image: 'images/apple-iphone-15-pro-max-1.jpg',
    badge: ['Pro Max', 'Pro Max'],
    description: ['أقوى إصدار من فئة 15، بعدسة تقريب خماسية وأداء احترافي بلا حدود.',
      'The most powerful 15-series model, with a 5x telephoto lens and pro-level performance.'],
    colors: [['تيتانيوم طبيعي', 'Natural titanium'], ['تيتانيوم أزرق', 'Blue titanium'], ['تيتانيوم أبيض', 'White titanium'], ['تيتانيوم أسود', 'Black titanium']],
    storage: ['256GB', '512GB', '1TB'],
    specs: [['عدسة تقريب بصري 5x', '5x optical zoom lens'], ['شريحة A17 Pro', 'A17 Pro chip'], ['شاشة 6.7 إنش', '6.7" display']],
  },
  {
    id: 'iphone-16', name: 'iPhone 16', brand: 'Apple', category: 'iPhone', generation: 16,
    image: 'images/apple-iphone-16-1.jpg',
    badge: ['جديد', 'New'],
    description: ['تصميم جديد بالكامل مع كاميرا Fusion محسّنة وزر Camera Control الجديد.',
      'All-new design with an improved Fusion camera and the new Camera Control button.'],
    colors: [['أسود', 'Black'], ['أبيض', 'White'], ['وردي', 'Pink'], ['أزرق مخضر', 'Teal'], ['أزرق أولترامارين', 'Ultramarine']],
    storage: ['128GB', '256GB', '512GB'],
    specs: [['شريحة A18', 'A18 chip'], ['زر Camera Control', 'Camera Control button'], ['شاشة 6.1 إنش', '6.1" display']],
  },
  {
    id: 'iphone-16-plus', name: 'iPhone 16 Plus', brand: 'Apple', category: 'iPhone', generation: 16,
    image: 'images/apple-iphone-16-plus-1.jpg',
    description: ['نفس قوة iPhone 16 في شاشة أكبر وبطارية تدوم طوال اليوم.',
      'The power of iPhone 16 in a larger display with all-day battery life.'],
    colors: [['أسود', 'Black'], ['أبيض', 'White'], ['وردي', 'Pink'], ['أزرق مخضر', 'Teal'], ['أزرق أولترامارين', 'Ultramarine']],
    storage: ['128GB', '256GB', '512GB'],
    specs: [['شاشة 6.7 إنش', '6.7" display'], ['شريحة A18', 'A18 chip'], ['بطارية يوم كامل', 'All-day battery']],
  },
  {
    id: 'iphone-16-pro', name: 'iPhone 16 Pro', brand: 'Apple', category: 'iPhone', generation: 16,
    image: 'images/apple-iphone-16-pro-1.jpg',
    badge: ['Pro', 'Pro'],
    description: ['شريحة A18 Pro وكاميرات احترافية مطورة لتصوير أدق في كل الظروف.',
      'A18 Pro chip and upgraded pro cameras for sharper shots in any light.'],
    colors: [['تيتانيوم صحراوي', 'Desert titanium'], ['تيتانيوم طبيعي', 'Natural titanium'], ['تيتانيوم أبيض', 'White titanium'], ['تيتانيوم أسود', 'Black titanium']],
    storage: ['128GB', '256GB', '512GB', '1TB'],
    specs: [['شريحة A18 Pro', 'A18 Pro chip'], ['هيكل تيتانيوم', 'Titanium body'], ['تسجيل فيديو احترافي', 'Pro video recording']],
  },
  {
    id: 'iphone-16-pro-max', name: 'iPhone 16 Pro Max', brand: 'Apple', category: 'iPhone', generation: 16,
    image: 'images/apple-iphone-16-pro-max-1.jpg',
    badge: ['Pro Max', 'Pro Max'],
    description: ['أكبر شاشة وأطول عمر بطارية في تشكيلة آيفون، بأداء احترافي كامل.',
      'The largest display and longest battery life in the iPhone lineup, with full pro performance.'],
    colors: [['تيتانيوم صحراوي', 'Desert titanium'], ['تيتانيوم طبيعي', 'Natural titanium'], ['تيتانيوم أبيض', 'White titanium'], ['تيتانيوم أسود', 'Black titanium']],
    storage: ['256GB', '512GB', '1TB'],
    specs: [['شاشة 6.9 إنش', '6.9" display'], ['شريحة A18 Pro', 'A18 Pro chip'], ['أطول عمر بطارية', 'Longest battery life']],
  },
  {
    id: 'iphone-17', name: 'iPhone 17', brand: 'Apple', category: 'iPhone', generation: 17,
    image: 'images/apple-iphone-17-1.jpg',
    badge: ['الأحدث', 'Latest'],
    description: ['الجيل الأحدث بتصميم منعش وألوان جريئة وأداء يومي فائق السرعة.',
      'The latest generation with a fresh design, bold colors and very fast everyday performance.'],
    colors: [['أسود', 'Black'], ['أبيض', 'White'], ['أرجواني فاتح', 'Light purple'], ['أخضر', 'Green'], ['أزرق داكن', 'Dark blue']],
    storage: ['256GB', '512GB'],
    specs: [['شريحة A19', 'A19 chip'], ['كاميرا مزدوجة محسّنة', 'Enhanced dual camera'], ['شاشة ProMotion', 'ProMotion display']],
  },
  {
    id: 'iphone-17-pro', name: 'iPhone 17 Pro', brand: 'Apple', category: 'iPhone', generation: 17,
    image: 'images/apple-iphone-17-pro-1.jpg',
    badge: ['Pro', 'Pro'],
    description: ['تصميم احترافي جديد بهيكل ألمنيوم متطور ونظام كاميرات من الجيل التالي.',
      'A new pro design with an advanced aluminum body and next-generation camera system.'],
    colors: [['برتقالي كوزميك', 'Cosmic orange'], ['أزرق داكن', 'Dark blue'], ['فضي', 'Silver']],
    storage: ['256GB', '512GB', '1TB'],
    specs: [['شريحة A19 Pro', 'A19 Pro chip'], ['نظام تبريد متطور', 'Advanced cooling system'], ['تصوير احترافي', 'Pro photography']],
  },
  {
    id: 'iphone-17-pro-max', name: 'iPhone 17 Pro Max', brand: 'Apple', category: 'iPhone', generation: 17,
    image: 'images/apple-iphone-17-pro-max-1.jpg',
    badge: ['Pro Max', 'Pro Max'],
    description: ['قمة أداء آيفون هذا العام، لمن يريد الأقوى والأكبر بلا مساومة.',
      'Top iPhone performance this year, for those who want the biggest and strongest with no compromise.'],
    colors: [['برتقالي كوزميك', 'Cosmic orange'], ['أزرق داكن', 'Dark blue'], ['فضي', 'Silver']],
    storage: ['256GB', '512GB', '1TB', '2TB'],
    specs: [['شريحة A19 Pro', 'A19 Pro chip'], ['أكبر بطارية في السلسلة', 'Largest battery in the lineup'], ['شاشة 6.9 إنش', '6.9" display']],
  },
  {
    id: 'iphone-18-pro', name: 'iPhone 18 Pro', brand: 'Apple', category: 'iPhone', generation: 18,
    image: 'images/apple-iphone18-pro-1.jpg',
    badge: ['وصل حديثاً', 'Just arrived'],
    description: ['أحدث إصدار احترافي من آبل بمواصفات الجيل القادم.',
      "Apple's newest pro model with next-generation specs."],
    storage: ['256GB', '512GB', '1TB'],
    specs: [['أحدث شريحة من آبل', 'Latest Apple chip'], ['نظام كاميرات متطور', 'Advanced camera system']],
  },
  {
    id: 'iphone-18-pro-max', name: 'iPhone 18 Pro Max', brand: 'Apple', category: 'iPhone', generation: 18,
    image: 'images/apple-iphone18-pro-max-1.jpg',
    badge: ['وصل حديثاً', 'Just arrived'],
    description: ['الإصدار الأحدث والأكبر من آبل — أول شحنة وصلت للمتجر.', "Apple's newest and largest model."],
    storage: ['256GB', '512GB', '1TB', '2TB'],
    specs: [['أحدث شريحة من آبل', 'Latest Apple chip'], ['أكبر شاشة وأطول بطارية', 'Largest display and longest battery']],
  },
  {
    id: 'apple-watch-ultra-4', name: 'Apple Watch Ultra 4', brand: 'Apple', category: 'Apple Watch',
    image: 'images/apple-watch-ultra-4-1.jpg',
    badge: ['Ultra', 'Ultra'],
    description: ['أقوى ساعة من آبل للمغامرين والرياضيين، بمتانة عالية وبطارية تدوم لأيام.',
      "Apple's most rugged watch for adventurers and athletes, with high durability and multi-day battery."],
    storage: ['49mm'],
    specs: [['مقاوم للماء حتى 100م', 'Water resistant to 100 m'], ['بطارية تدوم أياماً', 'Multi-day battery'], ['GPS + خلوي', 'GPS + Cellular']],
  },
];

const L = ([ar, en]: Pair): L10n => ({ ar, en });

export const products: Product[] = RAW.map((r) => ({
  id: r.id, name: r.name, brand: r.brand, category: r.category, image: r.image,
  generation: r.generation, price: r.price, condition: r.condition, sim: r.sim && L(r.sim),
  badge: r.badge && L(r.badge),
  description: L(r.description),
  colors: (r.colors ?? []).map(L),
  storage: r.storage ?? [],
  specs: (r.specs ?? []).map(L),
}));
