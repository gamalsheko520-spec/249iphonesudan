import path from 'path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  // './' keeps the build working at a domain root or in a sub-folder
  // (GitHub Pages, Netlify, Cloudflare Pages, any static host).
  base: './',
  resolve: {
    alias: { '@': path.resolve(__dirname, '.') }
  },
  build: { outDir: 'dist' }
});
